// Modified Date: 2005-12-21 15:43:09
// Modified Language: 2340393254
	//<script language="javascript">
	//<!--
	//function AddLine(pyaddline,pwindow) { // JW - not in use i believe
	//	var retval;
	//	if (confirm('Create New Data Record?')) {  //neuen datensatz anlegen
	//		var retval = EventValue(YUCI,YUSER,YFORM.value,'FIX','COMGridEdit31S','CREATE','6','');
	//		pyaddline=1;
	//	}
	//	pwindow.event.returnValue=false;
	//	pwindow.event.cancelBubble=true;
	//}
 	function cgeOnScroll() {
	 	try {
	 		gridhead.style.left=-gridbodyDIV.scrollLeft;
 			gridhead2.style.left=-gridbodyDIV.scrollLeft;
	 	} catch(e) {
	 	}
 	}
	function gridonmousemove(pgridhead,pevent,pgridbody,pthis) {
	// SR11328
	//	if (pthis.offsetLeft+pthis.offsetWidth-gridbodyDIV.scrollLeft-pevent.clientX<5) {
		if (pthis.offsetLeft+pthis.offsetWidth-gridbodyDIV.scrollLeft-(pevent.clientX+document.body.scrollLeft)<5) {
			pthis.style.cursor='col-resize';
		} else {
			if (GRIDNumPages==1) {		// SR11573 - sort only if one page
				pthis.style.cursor='hand';
			} else {
				pthis.style.cursor='auto';
			}
		}
	}
	function gridonclick(pgridhead,pevent,pgridbody,pthis) {
		pthis=findObjectTagName(pthis,'TH');
		cgeCancelDrag();
		moveFocus(getFocusField(),1,0);
		if (pthis.offsetLeft+pthis.offsetWidth-gridbodyDIV.scrollLeft-pevent.clientX>=5) {
			if (GRIDNumPages==1) {		// SR11573 - sort only if one page
				sortColumn(pevent,pgridbody);
			}
		}
	}
	function windowsetTimeout(pstrCommand,pintDelay)	{
		if (0) {
			window.setTimeout(pstrCommand,pintDelay)
		} else {
			eval(pstrCommand)
		}
	}
	function ClearErrors(pintLine) {
		var intCols;
		var i;
		var objChild;
		objChild=gridbody.children[pintLine-1];
		if (objChild!=undefined) {
			intCols=gridbody.children[pintLine-1].length-1;
			for (var i = 0; i < intCols; i++) {
				gridbody.children[pintLine-1].children[i].error=0;
			}
		}
	}
	function GetBorderStyle(pthis) {
		var strBorder;
		var focusfield;
		var value;
		strBorder="1px outset";
		if (gridhead.resizing=='') {
			//if (document.getElementById('focusfield').value=='') {
				//document.getElementById('focusfield').value='tdY1_1';
			//}
			focusfield=getFocusField();
			if ((pthis!=null)&&(document.getElementById('activegrid').value!='')) {
				if ((pthis.id==focusfield)&&(pthis.id!='')&&(focusfield!='')) {
					value=document.getElementById(focusfield).value;
					if (document.getElementById('activefield').value=='') {
						strBorder="2px solid black";
					} else {
						strBorder="1px outset";
					}
					if (pthis.tooltip!=null) {
						pthis.title=pthis.tooltip;
					} else {
						pthis.title='';
					}
				//} else if (((pthis.innerText=='  ')||(pthis.innerText=''))&&(pthis.required==1)) {
				} else {
					if ((pthis.innerText=='  ')&&(pthis.required==1)) {
						strBorder="1px solid red";
					} else if (pthis.error==1) {
						strBorder="1px solid blue";
						pthis.tooltip='Error';
					} else {
						strBorder="1px outset";
						if (pthis.tooltip!=null) {
							pthis.title=pthis.tooltip;
						} else {
							pthis.title='';
						}
					}
				}
			}
		}
		return strBorder;
	}
	function SetFocus(pstrName) {
		var blnSharedForm=document.getElementById('sharedform').value;
		document.getElementById('activegrid').value=pstrName;
		if ((pstrName=='')&&(blnSharedForm==1)) {
			gridDIV.style.border='2px solid gray';
		} else {
			gridDIV.style.border='2px solid blue';
			if (gridbody.rows.length==0) {
				//on first entry into an empty grid.  SR12409
				if (event.srcElement.id.split("_")[0]!="CLICK") {
					if (document.getElementById('addnew').value==1) {
						var retval = EventValue(YUCI,YUSER,YFORM,"FIX","COMGridEdit31S","CREATE","6","");
						gridbodyDIV.onscroll();
					}
				}
			}
		}
		if ((getFocusField()!='')&&(getFocusField()!='td'+document.getElementById('activefield').value)) {
			//SR12058
			document.getElementById(getFocusField()).style.border=GetBorderStyle(document.getElementById(getFocusField()));
		}
	}
	function getDIVheight(pMaxHeight) {
		var height;
		height=gridbodyDIV.offsetTop+gridbodyDIV.scrollHeight;
		if (height>pMaxHeight) {
			height=pMaxHeight-gridbodyDIV.offsetTop;
		}
		return height;
	}
	function getDIVheight1(pMaxHeight) {
		var heightlines;
		var length;
		var i;
		var scrollBarHeight;
		heightlines=0;
		scrollBarHeight=0;
		length=gridbody.children[0].children.length-1;
		for (var i = 0; i < length; i++) {
			heightlines = heightlines + gridbody.children[0].children[i].clientHeight;
		}
		heightlines=gridbody.scrollHeight;
		height=heightlines+gridhead.clientHeight;
		height=gridbody.offsetHeight;
		if (height>pMaxHeight) {
			height=pMaxHeight-gridhead.clientHeight;
		}
		return height;
	}
	function schAlert(pstr) {
		activateField(event.srcElement.id.substr(2,999),'white');
		//event.srcElement.parentElement.focus();
	}
	function getDIVheight2(pMaxHeight) {
		var height;
		var length;
		var i
		height=0;
		if (gridbody.children.length>0) {
			length=gridbody.children[0].children.length-1;
			for (var i = 0; i < length; i++) {
				//height = height + gridhead.children[i].offsetHeight;
				alert(gridhead.children[0].children[i].tagName);
			}
			//height=height;
			if (pMaxHeight==0) {
				height=null;
			} else { 
				if (pMaxHeight<height) {
					//height=pMaxHeight;
				}
			}
		}
		return height;
	}
	function getDIVwidth(pMaxWidth) {
		var width;
		var i;
		var length;
		width=0;
		length=gridhead.children[0].children[0].children.length;
		for (var i = 0; i < length; i++) {
			width = width + gridhead.children[0].children[0].children[i].offsetWidth;
		}
		width=width+16+4;
		if (pMaxWidth==0) {
			width=null;
		} else if (width>(pMaxWidth-gridDIV.offsetLeft)) {
			width=pMaxWidth-gridDIV.offsetLeft;
		}
		return width;
	}
 	function moveFocusTop() {
	 	if (TBODY.children.length>0) {
 			moveFocus(TBODY.children[0].children[TBODY.children[0].children.length-1].id,1,0,1);
			moveFocus(36);
	 	}
	}
 	function moveFocusBottom() {
	 	if (TBODY.children.length>0) {
 			moveFocus(TBODY.children[TBODY.children.length-1].children[TBODY.children[0].children.length-1].id,1,1,1);
			moveFocus(36);
	 	}
	}
	function moveFocus(richt,fix,nofocus,normcolor) {
		var focusFieldNew;
		var blnFocusFlag;
		var objFocusField;
		var focusfield=getFocusField();
 		if ((richt!=focusfield)||(fix==1)) {
			if (fix == 1) {
				setFocusField(richt);
				if (richt!='') {
					if (document.getElementById(richt)!=null) {
						document.getElementById(richt).parentNode.firstChild.style.fontWeight='bold';
						if (normcolor == 1) {
							document.getElementById(richt).style.border='2px solid black';
						} else {
							document.getElementById(richt).style.border='2px solid red';
							document.getElementById(richt).value='+';
						}
						if (nofocus != 1) document.getElementById(richt).focus();
					}
				}
				if (focusfield != '') {
					objFF = document.getElementById(focusfield);
					objFF.parentNode.firstChild.style.fontWeight='normal';
					objFF.style.border='none';
					//objFF.style.border='1px outset';
					objFF.style.border=GetBorderStyle(objFF);
				}
			} else if (focusfield!='') { // JW 1-Dec-2004: Make sure there is a line
				/* SR11186
				colour = document.getElementById(focusfield).style.backgroundColor
				blnFocusFlag=((colour=='ivory')||(colour=='white'))
				*/
				blnFocusFlag=false
				focusfieldNew=focusfield;
				document.getElementById(focusfieldNew).parentNode.firstChild.style.fontWeight='normal';
				objFocusField=document.getElementById(focusfield);
				if        (richt==9)  { focusfieldNew=moveFocusTab(focusfield);
				} else if (richt==37) { focusfieldNew=moveFocusLeft(focusfield);
				} else if (richt==39) { focusfieldNew=moveFocusRight(focusfield);
				} else if (richt==38) { focusfieldNew=moveFocusUp(objFocusField);   //note object
				} else if (richt==40) { focusfieldNew=moveFocusDown(objFocusField); //note object
				} else if (richt==36) { focusfieldNew=moveFocusHome(focusfield);
				} else if (richt==35) { focusfieldNew=moveFocusEnd(focusfield);
				} else if (richt==34) { focusfieldNew=moveFocusPgDn(focusfield);
				} else if (richt==33) { focusfieldNew=moveFocusPgUp(focusfield);
				}	
				document.getElementById(focusfieldNew).parentNode.firstChild.style.fontWeight='bold';
				var focusfieldMessage=focusfield+':'+focusfieldNew;
				retval=focusfieldNew;
				if (retval != '' && retval !=richt) {
					setFocusField(retval);
					focusfieldNew=document.getElementById(retval);
					objFocusField.style.border='none';
					objFocusField.style.border=GetBorderStyle(objFocusField);
					focusfieldNew.style.border=GetBorderStyle(focusfieldNew);
					if ((focusfieldNew.offsetLeft+focusfieldNew.offsetWidth)>(gridDIV.offsetWidth+gridbodyDIV.scrollLeft)) {
						gridbodyDIV.scrollLeft=(focusfieldNew.offsetLeft+focusfieldNew.offsetWidth-gridDIV.clientWidth);
					}
					if ((focusfieldNew.offsetLeft)<(gridbodyDIV.scrollLeft+10)) {
						gridbodyDIV.scrollLeft=(focusfieldNew.offsetLeft);
						if (gridbodyDIV.scrollLeft<200) {
							gridbodyDIV.scrollLeft=0;
						}
					}
					if ((focusfieldNew.offsetTop+focusfieldNew.offsetHeight)>(gridbodyDIV.offsetHeight+gridbodyDIV.scrollTop)) {
						gridbodyDIV.scrollTop=focusfieldNew.offsetTop+gridbodyDIV.scrollTop;
					} else if ((focusfieldNew.offsetTop)<(gridbodyDIV.scrollTop)) {
						gridbodyDIV.scrollTop=focusfieldNew.offsetTop;
					}
				}
			}
			if (document.getElementById('gridhead2')!=null) {
				if ((getFocusField()=='') || (document.getElementById(getFocusField()).parentNode._Form) == YFORM) {
					gridhead2.style.zIndex=-1;
					gridhead.style.zIndex=10;
				} else {
					gridhead2.style.zIndex=10;
					gridhead.style.zIndex=-1;
				}
			}
			gridbodyDIV.onscroll();   //SR12798
		} 
		function moveFocusLeft(pfocusfield) {
			var focusfieldNew=pfocusfield;
			var objPrev;
			var blnFlag=true;
			while (blnFlag==true) {
				objPrev = document.getElementById(focusfieldNew).previousSibling;
				if (objPrev!=null) {
					if (objPrev.id == '') {
						focusfieldNew=pfocusfield;
						blnFlag=false;
					} else if (objPrev.id.search("key")>-1) {
						focusfieldNew=pfocusfield;
						blnFlag=false;
					} else {
						//if (document.getElementById(focusfieldNew).style.backgroundColor!='ivory') {
						if (!isHiddenCol(objPrev)) { // SR11848: Keep going if hidden
							if (objPrev.getAttribute("Locked")) {
								if (blnFocusFlag==false) {
									blnFlag=false;
								}
							} else {
								blnFlag=false;
							}
						}
						focusfieldNew=objPrev.id;
					}
				} else {
					focusfieldNew=pfocusfield;
					blnFlag=false;
				}
			}
			return focusfieldNew;
		}
		function moveFocusRight(pfocusfield) {
			var focusfieldNew=pfocusfield;
			var objNext;
			var blnFlag=true;
			while (blnFlag==true) {
				objNext = document.getElementById(focusfieldNew).nextSibling;
				if (objNext == null) {
					focusfieldNew=pfocusfield;
					blnFlag=false;
				} else {
					//if (document.getElementById(focusfieldNew).style.backgroundColor!='ivory') {
					if (!isHiddenCol(objNext)) { // SR11848: Keep going if hidden
						if (objNext.getAttribute("Locked")) {
							if (blnFocusFlag==false) {
								blnFlag=false;
							}
						} else {
							blnFlag=false;
						}
					}
					focusfieldNew=objNext.id;
				}
			}
			return focusfieldNew;
		}
		function moveFocusUp(pobjFocusField) {
			var focusfieldNew=pobjFocusField.id;
			//var previousSibling=pobjFocusField.parentNode.previousSibling;
			var previousSibling=getPreviousSibling(pobjFocusField.parentNode);
			var quit=(previousSibling==null);
			while (!quit) {
				if (previousSibling==null) {
					quit=true;
				} else {
					// This handles non-displayed lines
					//if ((previousSibling.style.display!="none")&&(previousSibling.id.indexOf('_')==-1)) {
					if (previousSibling.style.display!="none") {
						try {
							focusfieldNew=previousSibling.children[pobjFocusField.cellIndex].id;
							quit=true;
						} catch (Exception) {
							previousSibling=getPreviousSibling(previousSibling);
						}
					} else {
						//previousSibling=previousSibling.previousSibling;
						previousSibling=getPreviousSibling(previousSibling);
						if (previousSibling==null) {
							quit=true;
						}
					}
				}
			}				
			return focusfieldNew;
		}
		function getNextSibling(pobjNode) {
			var objNode;
			var intCol;
			objNode=pobjNode;
			if (currentHeader().id=='gridhead') {
				objNode=objNode.nextSibling;
			} else {
				try {
					objNode=objNode.parentNode.parentNode.parentNode.parentNode.nextSibling.children[0].children[0].children[0].children[0];
				} catch (Exception) {
					objNode=null;
				}
			}
			return objNode;
		} // end function
		function getPreviousSibling(pobjNode) {
			var objNode;
			var intCol;
			objNode=pobjNode;
			if (currentHeader().id=='gridhead') {
				objNode=objNode.previousSibling;
			} else {
				try {
					objNode=objNode.parentNode.parentNode.parentNode.parentNode.previousSibling.children[0].children[0].children[0].children[0];
				} catch (Exception) {
					objNode=null;
				}
			}
			return objNode;
		} // end function
		function moveFocusDown(pobjFocusField) {
			var focusfieldNew=pobjFocusField.id;
			//var nextSibling=pobjFocusField.parentNode.nextSibling;
			var nextSibling=getNextSibling(pobjFocusField.parentNode);
			var quit=(nextSibling==null);
			while (!quit) {
				if (nextSibling==null) {
					quit=true;
				} else {
					// This handles non-displayed lines
					//if ((nextSibling.style.display!="none")&&(nextSibling.id.indexOf('_')==-1)) {
					if (nextSibling.style.display!="none") {
						try {
							focusfieldNew=nextSibling.children[pobjFocusField.cellIndex].id;
							quit=true;
						} catch (Exception) {
							nextSibling=getNextSibling(nextSibling);
						}
					} else {
						//nextSibling=nextSibling.nextSibling;
						nextSibling=getNextSibling(nextSibling);
						if (nextSibling==null) {
							quit=true;
						}
					}
				}
			}			
			return focusfieldNew;
		}		
		function moveFocusTab(pfocusfield) {
			var focusfieldNew=pfocusfield;
			var nextSibling;
			var objChildren=document.getElementById(pfocusfield).parentNode.children;
			var moving;
			// var colour = document.getElementById(pfocusfield).style.backgroundColor;
			// blnFocusFlag=((colour=='ivory')||(colour=='white'));
			blnFocusFlag=true  // SR11186
			do {
				if ((event.shiftKey==false)&&(event.shiftLeft==false)) {
					if (objChildren[objChildren.length-1].id == document.getElementById(pfocusfield).id) {
						focusfieldNew=moveFocusTabNextRow(pfocusfield);
					} else {
						focusfieldNew=moveFocusRight(pfocusfield);
						if (pfocusfield==focusfieldNew) {
							focusfieldNew=moveFocusTabNextRow(pfocusfield);
							/* SR11186
							if (document.getElementById(focusfieldNew).style.backgroundColor!='ivory') {
								if (blnFocusFlag==true) {
									focusfieldNew=moveFocusRight(focusfieldNew);
								}
							} */
						}
					}
				} else {
					if (objChildren[1].id==document.getElementById(pfocusfield).id) {
						focusfieldNew=moveFocusTabPrevRow(pfocusfield);
					} else {
						focusfieldNew=moveFocusLeft(pfocusfield);
						if (pfocusfield==focusfieldNew) {
							focusfieldNew=moveFocusTabPrevRow(pfocusfield);
							/* SR11186
							if (document.getElementById(focusfieldNew).style.backgroundColor!='ivory') {
								if (blnFocusFlag==true) {
									focusfieldNew=moveFocusLeft(focusfieldNew);
								}
							} */
						}
					}
				}
				// SR11186
				if (pfocusfield==focusfieldNew) {  // no more enabled fields
					focusfieldNew = focusfield
					moving=false
				} else {
					pfocusfield=focusfieldNew
					/* Removed for SR10061 by RobertW
						moving = (document.getElementById(focusfieldNew).style.backgroundColor=='lightgrey')
					*/
					moving = document.getElementById(focusfieldNew).getAttribute("Locked")
				}
			} while (moving)
			return focusfieldNew;
		}
		// 9-Mar-2005 JW	SR11848: Replaced.
		function moveFocusTabNextRow(pfocusfield) {
			var retval
			// Move down - if can, then move home.
			var focusfieldNew = moveFocusDown(document.getElementById(pfocusfield))
			if (focusfieldNew == pfocusfield) {
				if (document.getElementById('addnew').value==1) {
					// Can't move down, but can create new row. so do it, and repeat.
					retval = EventValue(YUCI,YUSER,YFORM,"FIX","COMGridEdit31S","CREATE","6","");
					focusfieldNew = moveFocusTabNextRow(pfocusfield)
				}
			} else {
				focusfieldNew = moveFocusHome(focusfieldNew)
			}
			return focusfieldNew;
		}
		// 9-Mar-2005 JW	SR11848: Replaced.
		function moveFocusTabPrevRow(pfocusfield) {
			// Move up - if can, then move to end.
			var focusfieldNew = moveFocusUp(document.getElementById(pfocusfield))
			if (focusfieldNew != pfocusfield) {
				focusfieldNew = moveFocusEnd(focusfieldNew)
			}
			return focusfieldNew;
		}
		function moveFocusHome(pfocusfield) {
			var firstFld;
			var focusfieldNew=pfocusfield;
			if (document.getElementById(pfocusfield).firstChild != null) {
				//focusfieldNew=document.getElementById(pfocusfield).parentNode.parentNode.firstChild.children[1].id;
				var i = 1;
				do { // JW Don't go on primary keys
					firstFld = document.getElementById(pfocusfield).parentNode.children[i++];
				} while (firstFld.id=='')
				focusfieldNew=firstFld.id; // SR11247
				/* SR11186
				if (document.getElementById(focusfieldNew).style.backgroundColor!='ivory') {
					focusfieldNew=moveFocusRight(focusfieldNew);
				} */
				if (isHiddenCol(firstFld)) { // SR11848: Move over if hidden
					focusfieldNew = moveFocusRight(focusfieldNew);
				}
			}
			return focusfieldNew;
		}
		function moveFocusEnd(pfocusfield) {
			var lastFld;
			var focusfieldNew=pfocusfield;
			var objChildren;
			if (document.getElementById(focusfield).lastChild != null) {
				//objChildren=document.getElementById(pfocusfield).parentNode.parentNode.lastChild.children;
				objChildren=document.getElementById(pfocusfield).parentNode.children;
				lastFld=objChildren[objChildren.length-1];
				focusfieldNew=lastFld.id;
				/* SR11186
				if (document.getElementById(focusfieldNew).style.backgroundColor!='ivory') {
					focusfieldNew=moveFocusLeft(focusfieldNew);
				} */
				if (isHiddenCol(lastFld)) {// SR11848: Move over if hidden
					focusfieldNew = moveFocusLeft(focusfieldNew);
				}
			}
			return focusfieldNew;
		}
		function moveFocusPgDn(pfocusfield) {
			var focusfieldNew=pfocusfield;
			var parentNode=document.getElementById(pfocusfield).parentNode;
			if ((parentNode.rowIndex + 10) >= parentNode.parentNode.children.length) {	// JW >= not >
				parentNode.parentNode.children[parentNode.parentNode.children.length-1].children[document.getElementById(pfocusfield).cellIndex].scrollIntoView(true);
				var focusfieldNew = parentNode.parentNode.children[parentNode.parentNode.children.length-1].children[document.getElementById(pfocusfield).cellIndex].id;
			} else {
				parentNode.parentNode.children[parentNode.rowIndex + 10].children[document.getElementById(pfocusfield).cellIndex].scrollIntoView(true);
				var focusfieldNew = parentNode.parentNode.children[parentNode.rowIndex + 10].children[document.getElementById(pfocusfield).cellIndex].id;
			}
			return focusfieldNew;
		}
		function moveFocusPgUp(pfocusfield) {
			var focusfieldNew=pfocusfield;
			var parentNode=document.getElementById(pfocusfield).parentNode;
			if ((parentNode.rowIndex - 10) < 0) {
				var focusfieldNew = parentNode.parentNode.children[0].children[document.getElementById(focusfield).cellIndex].id;
			} else {
				var focusfieldNew = parentNode.parentNode.children[parentNode.rowIndex - 10].children[document.getElementById(focusfield).cellIndex].id;
			}
			return focusfieldNew;
		}
	}
	//----------  End MoveFocus Code-----------------------------------
	function StoreFocus() {
		var yfield=getFocusField().substring(2,999);
		var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31S','SETFOCUSFIELD','6',yfield);
	}
	function deleteRowOld(strCell) {
	  var previousFF = getFocusField();
	  var objCell=document.getElementById('td'+strCell);
	  var intLine=objCell.parentNode.rowIndex;
	  //x=y;
	  moveFocus(40);
	  if (getFocusField()==previousFF) {
		  moveFocus(38);
		  if (getFocusField()==previousFF) {
			  setFocusField('');
		  }
	  }
	  intLine=getGridRow(objCell);
	  expandObject(TBODY.rows[intLine].id);
	  document.all.gridbody.deleteRow(intLine);
	  if (intLine==0) { resetColumnWidths(); }
	}
function deleteRow(strCell) {
	  var previousFF = getFocusField();
	  var objCell=document.getElementById('td'+strCell);
	  var intLine=objCell.parentNode.rowIndex;
	  var strDelete='';
	  var strRef;
	  //if (TBODY.rows[intLine].id.indexOf('_')!=-1) {
	  if ('td'+strCell == previousFF) {
		  moveFocus(40);
		  if (getFocusField()==previousFF) {
			  moveFocus(38);
			  if (getFocusField()==previousFF) {
				  setFocusField('');
				  if (objCell.parentNode.id.indexOf('_')!=-1) {
					  strRef=document.getElementById(objCell.parentNode.id.split('_')[0]).rowIndex;
					  moveFocus(getFirstCell(TBODY.rows[strRef]),1,1,1);
				  }
			  }
		  }
	  }
	  intLine=getGridRow(objCell);
	  expandObject(TBODY.rows[intLine].id);
	  if (TBODY.rows[intLine].id.indexOf('_')==-1) {
		  for (var i = intLine+1; i < gridbody.rows.length; i++) {
			  if (gridbody.rows[i].id.indexOf('_')==-1) {
				  break;
			  } else {
		  	  	strCell=getFirstCell(gridbody.rows[i].children[0].children[0].children[0].children[0]).substring(2,9999);
		  	    strDelete=strCell+';'+i+','+strDelete;
		 	  }
		  }
	  }
	  if (strDelete!='') {
		  for ( i = 0; i < (strDelete.split(',').length-1); i++) {
			  strCell=strDelete.split(',')[i]
			  retval = EventValue(document.WWW.YUCI.value,document.WWW.YUSER.value,gridbody.rows[strCell.split(';')[1]].children[0].children[0].children[0].children[0]._Form,'FIX','COMGridEdit31S','KILL','6',strCell);
		  }
	  }	 
	  document.all.gridbody.deleteRow(intLine);
	  if (intLine==0) { resetColumnWidths(); }
	}
function deleteRowNew1(strCell) {
	  var previousFF = getFocusField();
	  var objCell=document.getElementById('td'+strCell);
	  var intLine=objCell.parentNode.rowIndex;
	  var strCell;
	  var strDelete='';
	  intLine=getGridRow(objCell);
	  expandObject(TBODY.rows[intLine].id);
	  for (var i = intLine+1; i < gridbody.rows.length; i++) {
		  if (gridbody.rows[i].id.indexOf('_')==-1) {
			  break;
		  } else {
	  	  	strCell=getFirstCell(gridbody.rows[i].children[0].children[0].children[0].children[0]).substring(2,9999);
	  	    strDelete=strCell+';'+i+','+strDelete;
	 	  }
	  }
	  if (strDelete!='') {
		  for ( i = 0; i < (strDelete.split(',').length-1); i++) {
			  strCell=strDelete.split(',')[i]
			  retval = EventValue(document.WWW.YUCI.value,document.WWW.YUSER.value,gridbody.rows[strCell.split(';')[1]].children[0].children[0].children[0].children[0]._Form,'FIX','COMGridEdit31S','KILL','6',strCell);
		  }
	  }	 
	  if (TBODY.rows[intLine].id.indexOf('_')!=-1) {
		  moveFocus(40);
		  if (getFocusField()==previousFF) {
			  moveFocus(38);
			  if (getFocusField()==previousFF) {
				  setFocusField('');
			  }
		  }
		  if (intLine==0) { resetColumnWidths(); }
	  }
	  document.all.gridbody.deleteRow(intLine);
	}
	function getFirstCell(objBODY) {
		var id='';
		for (var i = 0; i < objBODY.cells.length; i++) {
			objCell=objBODY.cells[i];
			if (objCell.id!='') {
				id=objCell.id;
				break;
			}
		}
		return id;
	}
	function getGridRow(pobj) {
		var idRow;
		var parentNode;
		var arr;
		idRow='';
		if (pobj!=null) {
			idRow=pobj.id;
			if ((idRow.substr(0,7)=='GridRow')&&(idRow.substr(idRow.length-1)!='a')) {
				idRow=pobj.rowIndex;
			} else {
				idRow=getGridRow(pobj.parentNode);
			}
		}
		return idRow;
	}
	function resetColumnWidths() {
		var intCells=gridheadRow.children.length;
		if (gridbody.rows.length>0) {
			for (var i = 0; i < intCells; i++) {
				if (gridbody.rows[0].cells[i]!=null) {
					gridbody.rows[0].cells[i].style.width=gridheadRow.cells[i].style.width;
				}
			}
		}
	}
	// 10-Mar-2005 JW	SR11848: is the column that this cell is in, hidden?
	function isHiddenCol(objCell) {
		if (currentHeader()==gridhead) {
			return (gridheadRow.children[objCell.cellIndex].Hidden);
		} else {
			return gridheadRow2.children[objCell.cellIndex].Hidden;
		}
	}
	// 10-Mar-2005 JW	SR11848: hide or show a column.
	function hideShowColumn(idCol,pHide,pForm) {
		var focusfield;
		//if (pForm==YFORM) {
		//	var objTH = document.getElementById('THfld'+idCol);
		//} else {
		//	var objTH = document.getElementById('THfld2_'+idCol);
		//}
		var objTH=document.getElementById('THfld_'+pForm+'_'+idCol);
		var objTHstyle = objTH.style;
		if (objTH!=null) {
			if (objTH.Hidden != pHide) { // If not already hidden/showing
				objTH.Hidden = pHide;
				if (pHide) {
					objTHstyle.oldWidth = objTHstyle.width;
					if (pForm==YFORM) {
						objTH.oldInner = objTH.innerHTML;
						objTH.innerHTML = '';
						objTHstyle.width = 0;
					} else {
						objTHstyle.width=0;
						setWidth(objTH.cellIndex,0,'gridhead2');
					}
					focusfield = getFocusField();
					if ((focusfield!='') && document.getElementById(focusfield).cellIndex == objTH.cellIndex) {
						// FF is being hidden. Move focus.
						moveFocus(39,0,0,'');
						if (getFocusField()==focusfield) {
							moveFocusLeft(37,0,0,'');
						}
					}
				} else {
					if (objTHstyle.oldWidth!=null) {
						if (pForm==YFORM) {
							objTHstyle.width = objTHstyle.oldWidth;
							objTH.innerHTML = objTH.oldInner;
						} else {
							objTHstyle.width=objTHstyle.oldWidth;
							setWidth(objTH.cellIndex,objTHstyle.oldWidth,'gridhead2');
						}
					}
				}
				if (pForm==YFORM) {
					if (gridbody.rows.length>0) {
						gridbody.rows[0].cells[objTH.cellIndex].style.width = objTHstyle.width;
					}
				}
			}
		}
	}
 	//-->
	//</script>
	

	//<!--
	function gridControlsCheck(pYFIELDNAME,pYTEXT,pblnReadOnly) {
		var objCheck;
		objCheck=document.createElement('INPUT');
		objCheck.type='checkbox';
		objCheck.name=pYFIELDNAME;
		objCheck.id=pYFIELDNAME;
		objCheck.value=pYTEXT;
		if (pYTEXT==1) {
			objCheck.checked=true;
		}
		if (!pblnReadOnly) {
			objCheck.attachEvent('onClick',alert(1));
		}
	}
 	//-->
	

	//<script language="javascript">
	//<!--
	//----------------------------------
	//Column Dragging
	//----------------------------------
var cgeDragTimeOut=null;
function cgeCancelDrag() {
	if (cgeDragTimeOut!=null) {
		window.clearTimeout(cgeDragTimeOut);
		cgeDragTimeOut=null;
	}
}
function cgeDragColumn() {	
	if (blnCanDrag) {
		if (window.event.button==1) {
			var objHdr=findObjectTagName(event.srcElement,'TH');
			cgePos = event.clientX;
			cgeSize=getPageOffsetLeft(objHdr);
			cgeDragTimeOut=window.setTimeout('cgeDragColumnNow("'+objHdr.id+'")',500);
		}
	}
}
function cgeDragColumnNow(pidElement) {
	var objHdr=document.getElementById(pidElement);
	var el = document.createElement('div');
	el.id='move';
	el.moveElement=objHdr.id;
	el.className='head';
 	el.style.width=objHdr.style.width;
 	el.style.zIndex=10;
 	el.style.position='absolute';
 	el.innerHTML=objHdr.innerText;
 	el.style.top=getPageOffsetTop(objHdr);
 	el.style.left=cgeSize;
 	el.style.fontSize='x-small';
 	el.style.fontFamily='Arial';
 	el.style.fontWeight='bold';
 	el.style.textAlign='center';
 	el.style.border='1px outset';
 	el.style.filter = "progid:DXImageTransform.Microsoft.Alpha(opacity=60)";
    document.body.attachEvent("onmousemove", cgeDoDragColumn);
    document.body.attachEvent("onmouseup", cgeEndDragColumn);
    document.body.attachEvent("onlosecapture", cgeEndDragColumn);
    document.body.setCapture();
 	document.body.appendChild(el);
 	el = null;
} 	
function cgeDoDragColumn() {
	var sz = cgeSize + event.clientX - cgePos;
	move.style.left= sz;
}
function cgeEndDragColumn() {
	var InsertElement=null;
	var strValue='';
	var sz = cgeSize + event.clientX - cgePos;
	var hdr=gridheadRow;
	var FromId;
	var ToId;
	for (i=0;i<hdr.cells.length;i++) {
		if (hdr.cells[i].className=='THfld') { // Don't move primary keys
			if (getPageOffsetLeft(hdr.cells[i])<sz) {
				InsertElement=hdr.cells[i];
			}
		}
	}
	if (InsertElement!=null) {
		if (move.moveElement!=InsertElement.id) {
			var Node=document.getElementById(move.moveElement);
			FromId=Node.id;
			ToId=InsertElement.id;
			cgeSwapNodes(Node.cellIndex,InsertElement.cellIndex);
			Node.removeNode;
			//InsertElement.insertAdjacentElement('BeforeBegin',Node); SR13940
			InsertElement.insertAdjacentElement('AfterEnd',Node);
			var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31R','REORDERLAYOUT','6',FromId+';'+ToId);
		}
	}
	document.body.detachEvent("onmousemove", cgeDoDragColumn);
    document.body.detachEvent("onmouseup", cgeEndDragColumn);
    document.body.detachEvent("onlosecapture", cgeEndDragColumn);
    document.body.releaseCapture();
	move.outerHTML='';
	event.cancelBubble=true;
	return false;
}
function cgeSwapNodes(From,To) {
	var Rows;
	var i;
	var Node;
	var InsertElement;
	Rows=gridbody.children[0].children.length;
	for (i=0;i<Rows;i++) {
		if (gridbody.children[0].children[i].id.indexOf('_')==-1) {
			InsertElement=gridbody.children[0].children[i].children[To];
			Node=gridbody.children[0].children[i].children[From];
			Node.removeNode;
			//InsertElement.insertAdjacentElement('BeforeBegin',Node); SR13940
			InsertElement.insertAdjacentElement('AfterEnd',Node);
		}
	}
}
 	//-->
	//</script>
	

	//<script language="javascript">
	//<!--
	function hideMainLines() {
		var blnFlag=!TBODY._ShowMainLines;
		TBODY._ShowMainLines=!TBODY._ShowMainLines;
		for (var i=0;i<TBODY.rows.length;i++) {
			TBODY.rows[i].style.display = (!blnFlag || TBODY.rows[i].id.indexOf('_')!=-1) ? 'inline' : 'none';
		}
	}
	function childCount(pintRow) {
		var intCount=0;
		for (var i=pintRow+1;i<TBODY.rows.length;i++) {
			if (TBODY.rows[i].id.indexOf('_')==-1) {
				break;
			} else {
				intCount++;
			}
		}
		return intCount;
	}
	function lastChildId(pintRow) {
		var id=pintRow;
		for (var i=pintRow+1;i<TBODY.rows.length;i++) {
			if (TBODY.rows[i].id.indexOf('_')==-1) {
				break;
			} else {
				id=i;
			}
		}
		return TBODY.rows[id].id;
	}
	function moveFocusToNextLinkedLine(pKey) {
		var objRow;
		var intRow;
		var focusField=document.getElementById('focusField').value;
		var intCol=getColNum(focusField);
		if (focusField=='') {
			var objRow=TBODY.rows[0];
		} else {
			var objRow=TBODY.rows[getGridRow(document.getElementById(focusField))];
		}
		for (var i = (objRow.rowIndex+1); i < TBODY.rows.length; i++) {
			objRow=TBODY.rows[i];
			if (objRow._Links) {
				intRow=TBODY.rows[i].id.split('GridRow')[1];
				moveFocus('tdY'+intRow+'_'+intCol,1,1,1);
				break;
			}
		}
	}
	function moveFocusToPrevLinkedLine(pKey) {
		var objRow;
		var intRow;
		var focusField=document.getElementById('focusField').value;
		var intCol=getColNum(focusField);
		if (focusField=='') {
			var objRow=TBODY.rows[TBODY.rows.length-1];
		} else {
			var objRow=TBODY.rows[getGridRow(document.getElementById(focusField))];
		}
		for (var i = (objRow.rowIndex-1); i > -1; i--) {
			objRow=TBODY.rows[i];
			if (objRow._Links) {
				intRow=TBODY.rows[i].id.split('GridRow')[1];
				moveFocus('tdY'+intRow+'_'+intCol,1,1,1);
				break;
			}
		}
	}
 	// 19-Oct-2005	JW		SR11573: Don't call FIN code here. COMGridEdit31Body now calls this.
	function cgeShowHeaders() {
		if (document.WWW.YBED.value!='aSHOBBY') {
			cgeShowHeaders2();
			return;
		}
		var innerHTML;
		var newTable;
		var newRow;
		var newBody;
		var el=document.getElementById('gridhead2');
		if (el==undefined) {
			var el = document.createElement('div');
			el.id='gridhead2';
			el.className='head';
	 		el.style.zIndex=-1;
	 		el.style.position='absolute';
	 		el.style.backgroundColor='lightgreen';
		 	el.style.fontSize='x-small';
	 		el.style.fontFamily='Arial';
	 		el.style.fontWeight='bold';
	 		//el.style.textAlign='center';
		 	//el.style.filter = "progid:DXImageTransform.Microsoft.Alpha(opacity=60)";
		 	//GridRow1.style.filter = "progid:DXImageTransform.Microsoft.Alpha(opacity=60)";
			newTable=document.createElement('table');
			newTable.id='ELTable';
			newTable.cellSpacing=0;
			newTable.style.tableLayout='fixed';
			newTable.style.borderTop='1px';
			newTable.style.vAlign='middle';
			el.appendChild(newTable);		
			newBody=document.createElement('TBODY');
			newBody.id='ELBody';
			newTable.appendChild(newBody);			
			newRow=document.createElement('TR');
			newRow.id='gridheadRow2';
			newBody.appendChild(newRow);
	 		gridhead.appendChild(el);
	 		gridheadDIV.appendChild(el);
		 	el.style.width=gridheadRow.style.width;
			//SR11573
			//innerHTML=EventValue(YUCI,YUSER,document.WWW.YFORM.value,'GetHeader','GetHeader^FINAPInvAdditionalCharge','none','6','');
		}
		gridhead2.style.top=(gridhead.offsetTop);
	 	gridhead2.style.left=0;
	 	gridhead2.style.height=gridhead.offsetHeight;
	 	//el.style.width=gridhead.offsetWidth;
	 	//el.style.top=gridhead.offsetTop+(gridhead.offsetHeight-el.offsetHeight);
	 	el = null;
	}
	function cgeShowHeaders2() {
		var innerHTML;
		var newTable;
		var newRow;
		var newBody;
		var newHead;
		if (document.getElementById('gridhead2')==undefined) {
			newTable=document.createElement('table');
			newTable.id='gridhead2';
			newTable.className='TABLEhd';
			newTable.cellSpacing=0;
			newTable.style.position='absolute';
			newTable.style.borderTop='1px';
			gridheadDIV.appendChild(newTable);		
			//newBody=document.createElement('TBODY');
			//newBody.id='ELBody';
			newHead=document.createElement('THEAD');
			newHead.id='ELBody';
			newTable.appendChild(newHead);
			newRow=document.createElement('TR');
			newRow.id='gridheadRow2';
			newHead.appendChild(newRow);
			innerHTML=EventValue(YUCI,YUSER,document.WWW.YFORM.value,'GetHeader','GetHeader^FINAPInvAdditionalCharge','none','6','');
		}
		gridhead2.style.top=(gridhead.offsetTop);
	 	gridhead2.style.left=0;
	 	gridhead2.style.height=gridhead.offsetHeight;
	}
	function cgeHideHeaders() {
		if (document.getElementById('gridhead2')!=null) {
			gridhead2.style.display='none';
		}
	 	//gridhead.style.display='block';
	}
	function expandObject(pintRow) {
		var arr;
		var objParent;
		var objRow=TBODY.rows[pintRow];
		var id=objRow.id.split('GridRow')[1].split('_')[0];
		objParent=document.getElementById('GridRow'+id);
		if (childCount(objParent.rowIndex)==1) {
			// about to delete the last child
	  		objParent._Links=false;
			document.getElementById('Expand_'+id).src=cgeYGIF+'bplus.gif';
		}
	}
	function cgeExpandAll() {
		var strRowId;
		var intPos;
		var objExpand=document.getElementById('Expand');
		cgeCancelDrag();
		objExpand.src=(!objExpand._Expanded) ? cgeYGIF+'cminus.gif' : cgeYGIF+'cplus.gif';
		objExpand._Expanded=!objExpand._Expanded;
		for (var i = 0; i < TBODY.rows.length; i++) {
			strRowId=TBODY.rows[i].id;
			intPos=strRowId.indexOf("_");
			if (intPos==-1) {
				if (document.getElementById(strRowId)._Links) {
					var arr=strRowId.split('GridRow');
					cgeExpandEx(arr[1],'Expand_'+arr[1],objExpand._Expanded);
				}
			}
		}
		window.event.returnValue = false;
		window.event.cancelBubble = true;
	}
	var newRow;
	function cgeExpand(Row,State) {
		var id='Expand_'+Row
		if (document.getElementById('GridRow'+Row)._Links) {
			if (State==undefined) { 
				State=!document.getElementById(id)._Expanded;
			}
			cgeExpandEx(Row,id,State);
		}
	}
	function cgeCreateTotalsLine(Row) {
		alert('Hello');
		var objTR=document.createElement('TR');
		var objTD=document.createElement('td');
		var objFONT=document.createElement('FONT');
		objFONT.innerHTML='aaa';
		objTR.appendChild(objTD);
		objTD.appendChild(objFONT);
		//gridbody.children[gridbody.children.length-1].insertAdjacentElement('AfterEnd',objTR);
		//gridbody.children[gridbody.children.length-1].insertAdjacentElement('AfterEnd',objTR);
		gridbody.appendChild(objTR);
		////var newRow=cgeBodyRow(TBODY,2);
		//newRow=cgeBodyRow(TBODY,1);
		////var newRow=document.createElement('table');
		//var newTable=document.createElement('table');
		//newTable.style.overflow='hidden';
		//newTable.style.tableLayout='fixed';
		//newTable.cellSpacing=0;
		//newTable.style.width='100%';
		//newRow.appendChild(newTable);
		//newRow.style.visibility='visible';
		//gridbody.appendChild(newRow);
		//innerHTML=EventValue(YUCI,YUSER,document.WWW.YFORM.value,'GetHeader','GetHeader^FINAPInvAdditionalCharge','none','6','');
	}	
	// 19-Oct-2005	JW		SR11573: Pass in header. Don't call cgeShowHeaders or add line here.
	function cgeCreateExpandRow(Row,Data,Key,Show,Form,Parent) {
		var idIndex;
		var objRow;
		if (Key==undefined) Key='';
		if (Parent==undefined) Parent='';
		objRow=document.getElementById('GridRow'+Row);
		objRow._Links=true;
		for (var i = 1; i <99999; i++) {
			idIndex=Row+'_'+i;
			if (document.getElementById('GridRow'+idIndex)==undefined) {
				break;
			}
		}
		//cgeShowHeaders();
		//newRow=cgeBodyRow(TBODY,idIndex);
		newRow=cgeBodyRow(TBODY,idIndex,null,ELBody);	//SR11573
		document.getElementById(lastChildId(objRow.rowIndex)).insertAdjacentElement('AfterEnd',newRow);
		var newCell=cgeBodyFieldCell(newRow,'ExCon'+idIndex,0,'arial',10,'white','','','','-1','','','',ELBody);
		newCell.style.border='none';
		newCell.colSpan=objRow.cells.length-1;
		var newTable=document.createElement('table');
		newTable.style.overflow='hidden';
		newTable.style.tableLayout='fixed';
		newTable.cellSpacing=0;
		newTable.style.width='100%';
		newCell.appendChild(newTable);
		var newBody=document.createElement('tbody');
		newTable.appendChild(newBody);
		newRow=cgeBodyRow(newBody,idIndex+'a',Form,ELBody);
		newBody.appendChild(newRow);
		cgeExpand(Row,Show);
		//SR11573
		//var innerHTML=EventValue(YUCI,YUSER,document.WWW.YFORM.value,'ADDLINE','COMGridEdit31R','ADDLINE','6',Form+';'+Key+';'+idIndex+';'+Parent+';'+Data);
		//newRow=null;
		return newRow;
	}
	function setState(obj,State) {
		if (State==undefined) { State=true };
		obj._Expanded=State;
		obj.src = State ? cgeYGIF+'cminus.gif' : cgeYGIF+'cplus.gif';
	}
	function cgeExpandEx(Row,id,Expanded) {
		if (document.getElementById(id).src!='bplus.gif') {
			//Only if this row has linked Lines
			var strState = Expanded ? 'inline' : 'none';
			for (var i = document.getElementById('GridRow'+Row).rowIndex+1; i < TBODY.rows.length; i++) {
				if (TBODY.rows[i].id.indexOf('_')==-1) {
					break;
				} else {
					TBODY.rows[i].style.display=strState;
				}
			}
			setState(document.getElementById(id),Expanded);
			moveFocus(getFirstCell(document.getElementById('GridRow'+Row)),1,1,1);
			if (cgeAll(Expanded)) {
				document.getElementById('Expand')._Expanded=Expanded;
				document.getElementById('Expand').src = Expanded ? cgeYGIF+'cminus.gif' : cgeYGIF+'cplus.gif';
			}
		}
	}
	function cgeAll(pState) {
		var blnFlag=true;
		var intRow;
		for (var i = 0; i < TBODY.rows.length; i++) {
			if (TBODY.rows[i].id.indexOf('_')==-1) {
				intRow=TBODY.rows[i].id.split('GridRow')[1];
				if (document.getElementById('Expand_'+intRow)._Expanded!=pState) {
					blnFlag=false;
					break;
				}
			}
		}
		return blnFlag;
	}
 	//-->
	//</script>
	

	//<script language="javascript">
	//<!--
	//----------------------------------
	//Column Resizing
	//----------------------------------
	var cgeRatio=-1;
	window.attachEvent('onresize',gridDoResizeOnResize);
	function cgeBodyWidth() {
		//if (currentHeader().id='gridhead') {
			if (currentHeader().id=='gridhead') {
				return gridDIV.offsetWidth-4;
			} else {
				//window.status=gridhead2.offsetWidth+',,,';
				//gridbodyDIV.scrollWidth=gridhead2.offsetWidth-50;
				return gridDIV.offsetWidth-4;
			}
		//}
	}
	function currentHeader() {
		var result=gridhead;
		if (document.getElementById('gridhead2')!=null) {
			if (gridhead2.style!=null) {
				if (gridhead2.style.zIndex==10) {
					if (document.WWW.YBED.value!='aSHOBBY') {
						result=gridhead2;
					} else {
						result=gridhead2.children[0];
					}				
				}
			}
		}
		return result;
	}
	function gridStartColumnResize() {
		var el;
		var gridResize;
		gridCurrentColumn=event.srcElement.cellIndex;
		if (gridCurrentColumn==undefined) {
			gridCurrentColumn=event.srcElement.parentNode.parentNode.cellIndex;
		}
		var el=currentHeader().cells[gridCurrentColumn];
		if (el!=undefined) {
		// SR11328
			gridPos = event.clientX+document.body.scrollLeft;
			gridResize=el.offsetLeft+el.offsetWidth-gridbodyDIV.scrollLeft+4;
			if (gridResize-gridPos<6) {
				cgeCancelDrag();
				gridSize = el.offsetWidth;
				el.attachEvent("onmousemove", gridDoResize);
		        el.attachEvent("onmouseup", gridEndResize);
		        el.attachEvent("onlosecapture", gridEndResize);
		        el.setCapture();
			}
		}
        el = null;
        event.cancelBubble = true;
	}
	function gridDoResizeOnResize() { // SR11350 - This will cause the header to be redrawn correctly.
		var curPos = gridbodyDIV.scrollLeft;
		gridbodyDIV.scrollLeft = 1; // SR11328
		currentHeader().style.left = 0;
		gridbodyDIV.scrollLeft = curPos;
	}
	function gridDoResize(){
		var sz;
		var objHeadStyle=currentHeader().rows[0].cells[gridCurrentColumn].style;
		sz = gridSize + event.clientX - gridPos + document.body.scrollLeft;
		sz = sz < 5 ? 5 : sz;
		objHeadStyle.width = sz;
		if (gridbody.rows.length>0) {
			if (currentHeader().id=='gridhead') {
				var objBodyStyle=gridbody.rows[0].cells[gridCurrentColumn].style;
				objBodyStyle.width=sz;
				objBodyStyle.left=objHeadStyle.left;
				gridbody.style.left=currentHeader().style.left;
			}
		}
		gridbodyDIV.style.left=gridheadDIV.style.left;
	// SR11328
		gridbodyDIV.onscroll();
	}
	function gridEndResize() {
		var el;
		var width;
		var Form;
		el=currentHeader().cells[gridCurrentColumn];
        el.detachEvent("onmousemove", gridDoResize);
        el.detachEvent("onmouseup", gridEndResize);
        el.detachEvent("onlosecapture", gridEndResize);
        el.releaseCapture();
		gridDoResize();
	// SR11328
    	width = gridSize + event.clientX - gridPos + document.body.scrollLeft;
		if (width < 5) {width = 5}
		Form=setWidth(gridCurrentColumn,width,currentHeader().id);
        CallBack("OnColumnResize^COMGridEdit31Events",Form+';'+el.id,width/gridRatio());
        gridbodyDIV.onscroll();
        el = null;
	}
 	function setWidth(gridCurrentColumn,width,gridHeader) {
 		var Form='';
 		var i;
 		var objCell;
		for (i=0;i<gridbody.rows.length;i++) {
			if (gridbody.rows[i].id.indexOf('_')==-1) {
				if (gridHeader=='gridhead') {
					//without this right aligned columns don't adjust position of cell contents.
					objCell=gridbody.rows[i].cells[gridCurrentColumn]
					objCell.style.width=width;
					Form=objCell.parentNode._Form;
				}
			} else {
				if (gridHeader!='gridhead') {
					objCell=gridbody.rows[i].children[0].children[0].cells[gridCurrentColumn];
					objCell.style.width=width;
					Form=objCell.parentNode._Form;
				}
			}
		} 		
 		return Form;
 	}
	function gridRatio() {
		if (cgeRatio==-1) {
			var obj=document.getElementById('gridheadDIV');  //SR12282  //SR12375
			var intWidth=obj.offsetWidth;
			obj.style.width=intWidth+'pt';
			cgeRatio=obj.offsetWidth/intWidth;
			obj.style.width=intWidth;
		}
		return cgeRatio;
	}
 	//-->
	//</script>
	

	//<script language="javascript">
	//<!--
function cgeRightClick() {
	var srcElement;
	srcElement=findObjectTagName(window.event.srcElement,'TH');
	if (srcElement==null) {
		srcElement=findObjectTagName(window.event.srcElement,'TD');
	}
	if 	(srcElement!=null) {
		CallBackNow("Show^COMGridEdit31JRightClick",srcElement.id+','+srcElement.parentNode._Form);	
		if (Columns.document.body.children.length>0) {
			Columns.show(event.screenX,event.screenY,200,0);
			window.setTimeout('Columns.show('+event.screenX+','+event.screenY+',200,Columns.document.body.children[0].offsetHeight);',50);
		}
		event.returnvalue=false;
		event.cancelBubble=false;
	}
	return false;
}
 	//-->
	//</script>
	

	//<script language="javascript">
	//<!--
	/*----------------------------------------------------------------------------\
	|                                Table Sort                                   |
	|-----------------------------------------------------------------------------|
	|                         Created by Erik Arvidsson                           |
	|                  (http://webfx.eae.net/contact.html#erik)                   |
	|                      For WebFX (http://webfx.eae.net/)                      |
	|-----------------------------------------------------------------------------|
	| A DOM 1 based script that allows an ordinary HTML table to be sortable.     |
	|-----------------------------------------------------------------------------|
	|                  Copyright (c) 1998 - 2002 Erik Arvidsson                   |
	|-----------------------------------------------------------------------------|
	| This software is provided "as is", without warranty of any kind, express or |
	| implied, including  but not limited  to the warranties of  merchantability, |
	| fitness for a particular purpose and noninfringement. In no event shall the |
	| authors or  copyright  holders be  liable for any claim,  damages or  other |
	| liability, whether  in an  action of  contract, tort  or otherwise, arising |
	| from,  out of  or in  connection with  the software or  the  use  or  other |
	| dealings in the software.                                                   |
	| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
	| This  software is  available under the  three different licenses  mentioned |
	| below.  To use this software you must chose, and qualify, for one of those. |
	| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
	| The WebFX Non-Commercial License          http://webfx.eae.net/license.html |
	| Permits  anyone the right to use the  software in a  non-commercial context |
	| free of charge.                                                             |
	| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
	| The WebFX Commercial license           http://webfx.eae.net/commercial.html |
	| Permits the  license holder the right to use  the software in a  commercial |
	| context. Such license must be specifically obtained, however it's valid for |
	| any number of  implementations of the licensed software.                    |
	| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
	|*GPL - The GNU General Public License    http://www.gnu.org/licenses/gpl.txt |
	|*Permits anyone the right to use and modify the software without limitations |
	|*as long as proper  credits are given  and the original  and modified source |
	|*code are included. Requires  that the final product, software derivate from |
	|*the original  source or any  software  utilizing a GPL  component, such  as |
	|*this, is also licensed under the GPL license.                               |
	\----------------------------------------------------------------------------*/
	var dom = (document.getElementsByTagName) ? true : false;
	var ie5 = (document.getElementsByTagName && document.all) ? true : false;
	var arrowUp, arrowDown;
	if (ie5 || dom)
	 initSortTable();
	function initSortTable() {
	  arrowUp = document.createElement('SPAN');
	  var tn = document.createTextNode('5');
	  arrowUp.appendChild(tn);
	  arrowUp.className = 'arrow';
	  arrowUp.style.fontFamily='webdings';
	  arrowDown = document.createElement('SPAN');
	  var tn = document.createTextNode('6');
	  arrowDown.appendChild(tn);
	  arrowDown.className = 'arrow';
	  arrowDown.style.fontFamily='webdings';
	}
	function sortTable(tableNode, nCol, bDesc, sType) {
	  var tBody = tableNode.tBodies[0];
	  var trs = tBody.rows;
	  var trl= trs.length;
	  var a = new Array();
	  var b = new Array();
	  var j=-1;
	  var k=-1;
	  for (var i = 0; i < trl; i++) {
		if (trs[i].id.indexOf('_')==-1) {
		  j=j+1;
		  a[j] = trs[i];
		} else {
		  k=k+1;
		  b[k]=trs[i];
		}
	  }
	  var start = new Date;
	  window.status = 'Sorting data...';
	  a.sort(compareByColumn(nCol,bDesc,sType));
	  window.status = 'Sorting data done';
	  //x=y;
	  for (var i = 0; i < j+1; i++) {
	    tBody.appendChild(a[i]);
	    window.status = 'Updating row ' + (i + 1) + ' of ' + trl + ' (Time spent: ' + (new Date - start) + 'ms)';
	  }
	  //for (var i = 0; i < k+1; i++) {
	  for (var i = k; i > -1; i--) {
	    tBody.appendChild(b[i]);
	    document.getElementById(b[i].id.split('_')[0]).insertAdjacentElement('AfterEnd',b[i])
	    window.status = 'Updating row ' + (i + 1) + ' of ' + trl + ' (Time spent: ' + (new Date - start) + 'ms)';
	  }
	  // check for onsort
	  if (typeof tableNode.onsort == 'string')
	    tableNode.onsort = new Function('', tableNode.onsort);
	  if (typeof tableNode.onsort == 'function')
	    tableNode.onsort();
		resetColumnWidths();
	}
	function CaseInsensitiveString(s) {
	  return String(s).toUpperCase();
	}
	function parseDate(s) {
	  if (cgeDateFormat==null) {
	  	cgeDateFormat='DD/MM/YYYY';
	  }
	  var year = s.substring(cgeDateFormat.indexOf('Y'),cgeDateFormat.lastIndexOf('Y')+1),
	      month = s.substring(cgeDateFormat.indexOf('M'),cgeDateFormat.lastIndexOf('M')+1),
	      day = s.substring(cgeDateFormat.indexOf('D'),cgeDateFormat.lastIndexOf('D')+1);
	  return year+month+day;
	}
	/* alternative to number function
	 * This one is slower but can handle non numerical characters in
	 * the string allow strings like the follow (as well as a lot more)
	 * to be used:
	 *    '1,000,000'
	 *    '1 000 000'
	 *    '100cm'
	 */
	function toNumber(s) {
	    return Number(s.replace(/[^0-9\.\-]/g, ''));
	}
	function compareByColumn(nCol, bDescending, sType) {
	 var c = nCol;
	 var d = bDescending;
	 var fTypeCast = String;
	 if (sType == 'Number')
	  fTypeCast = toNumber;
	 else if (sType == 'Date')
	  fTypeCast = parseDate;
	 else if (sType == 'CaseInsensitiveString')
	  fTypeCast = CaseInsensitiveString;
	 return function (n1, n2) {
	  if (fTypeCast(getInnerText(n1.cells[c])) < fTypeCast(getInnerText(n2.cells[c])))
	   return d ? -1 : +1;
	  if (fTypeCast(getInnerText(n1.cells[c])) > fTypeCast(getInnerText(n2.cells[c])))
	   return d ? +1 : -1;
	  return 0;
	 };
	}
	function sortColumnWithHold(e) {
	 // find table element
	 var el = ie5 ? e.srcElement : e.target;
	 var table = getParent(el, 'TABLE');
	 // backup old cursor and onclick
	 var oldCursor = table.style.cursor;
	 var oldClick = table.onclick;
	 // change cursor and onclick
	 table.style.cursor = 'wait';
	 table.onclick = null;
	 // the event object is destroyed after this thread but we only need
	 // the srcElement and/or the target
	 var fakeEvent = {srcElement : e.srcElement, target : e.target};
	 // call sortColumn in a new thread to allow the ui thread to be updated
	 // with the cursor/onclick
	 window.setTimeout(function () {
	  sortColumn(fakeEvent);
	  // once done resore cursor and onclick
	  table.style.cursor = oldCursor;
	  table.onclick = oldClick;
	 }, 100);
	}
	function sortColumn(e,ptable) {
	 var tmp = e.target ? e.target : e.srcElement;
	 var tHeadParent = getParent(tmp, 'THEAD');
	 var el = getParent(tmp, 'TH');
	 if (tHeadParent == null)
	  return;
	 if (el != null) {
	  var p = el.parentNode;
	  var i;
	  // typecast to Boolean
	  el._descending = !Boolean(el._descending);
	  if (tHeadParent.arrow != null) {
	   if (tHeadParent.arrow.parentNode != el) {
	    tHeadParent.arrow.parentNode._descending = null;"_" //reset sort order
	   }
	   tHeadParent.arrow.parentNode.removeChild(tHeadParent.arrow);
	  }
	  if (el._descending)
	   tHeadParent.arrow = arrowUp.cloneNode(true);
	  else
	   tHeadParent.arrow = arrowDown.cloneNode(true);
	  el.appendChild(tHeadParent.arrow);
	  // get the index of the td
	  var cells = p.cells;
	  var l = cells.length;
	  for (i = 0; i < l; i++) {
	   if (cells[i] == el) break;
	  }
	//  var table = getParent(el, 'TABLE');
	  var table = ptable ? ptable : getParent(el, 'TABLE');   //shobby
	  // can't fail
	  sortTable(table,i,el._descending, el.getAttribute('type'));
	 }
	}
	function getInnerText(el) {
	 if (ie5) return el.innerText;"_" //Not needed but it is faster
	 var str = '';
	 var cs = el.childNodes;
	 var l = cs.length;
	 for (var i = 0; i < l; i++) {
	  switch (cs[i].nodeType) {
	   case 1: //ELEMENT_NODE
	    str += getInnerText(cs[i]);
	    break;
	   case 3:"_" //TEXT_NODE
	    str += cs[i].nodeValue;
	    break;
	  }
	 }
	 return str;
	}
	function getParent(el, pTagName) {
	 if (el == null) return null;
	 else if (el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase()) // Gecko bug, supposed to be uppercase
	  return el;
	 else
	  return getParent(el.parentNode, pTagName);
	}
function cgeSortColumnAscending(pField,pTable) {
	var table=document.getElementById(pTable);
	var event=document.createEventObject();
	var el=getParent(document.getElementById(pField), 'TH')
	el._descending=false;
	event.target=document.getElementById(pField);
	sortColumn(event,table);
}
function cgeSortColumnDescending(pField,pTable) {
	var table=document.getElementById(pTable);
	var event=document.createEventObject();
	var el=getParent(document.getElementById(pField), 'TH')
	el._descending=true;
	event.target=document.getElementById(pField);
	sortColumn(event,table);
}
 	//-->
	//</script>
	

//<script language="javascript">
//<!--
function cgeGridDate() {
	return '2005-12-13 15:06:56';
}
function cgeVarianceUpdate() {
	var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31R','VARIANCEUPDATE','6','');
}
function cgeTest(pstr) {
	alert(pstr);
}
	/*
function cgeStartBlock() {
	cgeAddBlock(0,0,"");
}
function cgeAddBlock(pblnContinue,pYROW,pYSUCH,pblnFlag) {
	var param=pblnContinue+'~'+pYROW+'~'+pYSUCH+'~200';
	var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31R','BODYADDROWS','6',param);
	retval=retval.split('~');
	var YROW=retval[0];
	var YSUCH=retval[1];
	var YFOCUSID=retval[2];
	if (YSUCH!='') {
		var strCommand='cgeAddBlock(1,\''+YROW+'\',\''+YSUCH+'\');';		
		window.setTimeout(strCommand,10);
	}
}
 	*/
function cgeAddBlock(pintPage,pstrFocus,pblnContinue) {	// SR11573: Rewritten
	var param=pintPage+'~'+pblnContinue
	var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31R','BODYADDROWS','6',param);
	if (pstrFocus=='T') {
		moveFocusTop();
		pstrFocus = '';
	}
	if (retval==1) {
		var strCommand='cgeAddBlock('+pintPage+',\''+pstrFocus+'\',1);';
		window.setTimeout(strCommand,10);
	} else {
		if (pstrFocus=='B') {
			moveFocusBottom();
		} else if (pstrFocus!='') {			// Move to pstrFocus cell
			moveFocus(pstrFocus,1,1,1);
			moveFocus(36);
		}
		document.WWW2.style.cursor = 'auto';
	}
}
function GoToPage(pintPage,numPages,pstrFocus,intBlnContinue) {	// SR11573: Created
	document.WWW2.style.cursor = 'wait';
	if (numPages == null) {
		numPages = pintPage;
	}
	GRIDNumPages = numPages;		// Global set
	pagesText(numPages,pintPage);
	if (intBlnContinue!=1) {	
		var af = document.getElementById('activefield').value;
		if (af!='') {
			saveDataNow(af);
		}
		setFocusField('');
		var objGrid = document.getElementById('gridbody');
		while (objGrid.rows.length>0) {
			objGrid.deleteRow();
		}
	}
	cgeAddBlock(pintPage,pstrFocus,intBlnContinue);
	//cgeStartBlock(pintPage,numPages,blnBottom);
}
function PerPage(obj) {
	var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31R','PERPAGE','6',obj.value);
	retval=retval.split('~');
	if (retval[0]==1) {
		GoToPage(1,retval[1],'T');
	} else {
		obj.value = retval[1];
	}
}
function pagesText(pMax,pCurrent,pGroup) {		// SR11573: Created
	var txt,grpSize,lstGrp,stop,start;
	grpSize = 10;
	if (pGroup == null) {
		pGroup = Math.floor((pCurrent-1) / grpSize + 1);
	}
	if (pGroup == 1) {
		txt = "&nbsp;"
	} else {
		txt = Link(1,"&lt;&lt") + Link(pGroup-1,"&lt");
	}
	stop = pGroup*grpSize;
	start = stop-grpSize+1;
	if (stop > pMax) {
		stop = pMax;
	}
	for (var i = start; i <= stop; i++) {
		if (pCurrent==i) {
			txt = txt+" <b>"+i+"</b>";
		} else {
			txt = txt+" <a href='#grid' onClick=\'GoToPage("+i+","+pMax+",\"T\");\'>"+i+"</a>";
		}
	}
	if (stop != pMax) {
		lstGrp = Math.floor((pMax-1) / grpSize + 1);
		txt = txt + Link(pGroup+1,"&gt") + Link(lstGrp,"&gt;&gt");
	}
	document.all.pages.innerHTML = txt;
	function Link(pGroup,pText) {
		return "&nbsp<a href='#grid' onClick=\'pagesText("+pMax+","+pCurrent+","+pGroup+");\'>"+pText+"</a>";
	}
}
function cgeUpdateValue(id,Value) {
	if (document.getElementById(id+'_checkbox')!=null) {
		document.getElementById(id+'_checkbox').checked=+Value;
	//} else if (document.getElementById(id)!=null) {
	} else {
		document.getElementById(id).firstChild.innerHTML=Value;
		//document.getElementById(id).style.color=Color;
	}
}
function isValid(value) {
	return ((value!="")&&(value!=null));
}		
function cgeUpdateStyle(id,objNewStyle) {
	var objObject=document.getElementById(id);
	if (objObject!=null) {
		var objStyle=objObject.style;
		objNewStyle=objNewStyle.split('~');
		if (isValid(objNewStyle[0])) objStyle.color=objNewStyle[0];
		if (isValid(objNewStyle[1])) objStyle.backgroundColor=objNewStyle[1];
		if (objNewStyle[2]!=null) objObject.title=objNewStyle[2];
	}
	return;
	//not used ??
	//if (document.getElementById(id+'_checkbox')!=null) {
	//	document.getElementById(id+'_checkbox').checked=+Value;
	//} else {
	//	document.getElementById(id).firstChild.innerHTML=Value;
	//	document.getElementById(id).style.color=fgColor;
	//	document.getElementById(id).firstChild.style.backgroundColor=bgColor;
	//	document.getElementById(id).style.border = '1px outset';
	//}
}
// ********************** Row Creation Code ******************************************************
var gCOLON='';
function RunMethod(pMethod) {
	var retval = EventValue(YUCI,YUSER,YFORM,'FIX','COMGridEdit31R','RUNMETHOD','6',pMethod);
	//return retval;
}
//function cgeBodyRow(Body,idRow,show) {
function cgeBodyRow(Body,idRow,Form,Header) {
	//var newRow=Body.insertRow(-1);
	var newRow=document.createElement('tr');
	newRow.id='GridRow'+idRow;
	newRow._Form=Form;
	newRow.style.fontSize='10pt';
	newRow.style.fontFamily='Symbol';
	// SR11573 - set header attribute
	newRow.Header = Header;
	//if (show==0) {
	//	newRow.style.display='none';
	//}
	//Body.appendChild(newRow);
	return newRow;
}
function cgeBodyRowEnd(Body,pnewRow) {
	Body.appendChild(pnewRow);
}
function cgeAddManyRows(Body,strBigString) {
	var i;
	var Rows=strBigString.split('~!@#$~');
	var intRows=Rows.length-1;
	for (i = 0; i != intRows ; i++) {
		var Cols=Rows[i].split('~');
		cgeBodyFieldCell(Cols[0],Cols[1],Cols[2],Cols[3],Cols[4],Cols[5],Cols[6],Cols[7],Cols[8],Cols[9],Cols[10],Cols[11],Cols[12]);
		cgeBodyRowEnd(Body);
	}
}
function cgeBodyFieldKey(Row,font,fontsize,height,backgroundColor,innerHTML) {
	var newCell=document.createElement('td');
	newCell.className='TDkey';
	//newCell.id='Key'+Row.children.length+'_'+Row.id;
	var cellStyle=newCell.style;
	cellStyle.font=fontsize+'pt '+font;
 	cellStyle.width=Row.Header.rows[0].cells[Row.children.length].style.width;		//SR11573 - use header
 	//cellStyle.width=gridhead.rows[0].cells[Row.children.length].style.width;
 	if (height!='') {
	 	cellStyle.height=height+'pt';
 	}
	cellStyle.backgroundColor=backgroundColor;
	newCell.innerHTML=unescape(innerHTML);
	//newCell.attachEvent('onmousedown',cgeOnMouseDownDisabled);
	Row.appendChild(newCell);
}
function cgeBodyFieldCell(strRow,fieldname,required,font,fontsize,backgroundColor,height,textAlign,innerHTML,enabled,title,pCOLON,fontcolor,Header) {
	gCOLON=pCOLON;
	var Row=strRow;
	var newCell=document.createElement('td');
	var strFont=fontsize+'pt '+font;
	newCell.id='td'+fieldname;
	newCell.required=required;
	if ((title!='')&&(title!=null)) {newCell.title=title;}
	newCell.noWrap=true;
	var cellStyle=newCell.style;
	if ((fontsize+'pt')!=Row.style.fontSize) {
		cellStyle.fontSize=fontsize+'pt';
	}
	//if (Row.style.font!=strFont) {cellStyle.font=strFont;}
	//cellStyle.font=fontsize+'pt '+font;
	//cellStyle.fontWeight='normal';
	if (fontcolor!='') { cellStyle.color=fontcolor;}
	newCell.className='TDfld';
	if (required==1) {
		if (innerHTML=='') {
			newCell.className='TDreq';
			cellStyle.border='1px solid red';
		}
	} else {
		//cellStyle.border='1px outset';
	}
	if (backgroundColor!='') {cellStyle.backgroundColor=backgroundColor;}
 	//if (height!='') { cellStyle.height=height;}
	//cellStyle.margin='0pt';
	//cellStyle.padding='0pt';
	if (textAlign!='') {
		cellStyle.textAlign=textAlign;
	}
	//newCell.setAttribute('Locked',enabled==0)
	newCell.Locked=enabled==0;
	if (enabled!=-1) {
		newCell.attachEvent('onmousedown',enabled==0?cgeOnMouseDownDisabled:cgeOnMouseDownEnabled);
	}
	if (innerHTML!='') {
		newCell.innerHTML=unescape(innerHTML);		
	}
	//SR11573 - use header
	cellStyle.width=Row.Header.rows[0].cells[Row.children.length].style.width;
	/*
	if (Header.id=='gridhead') {
		//if (TBODY.rows.length==0) {  //SR12743
		cellStyle.width=gridhead.rows[0].cells[Row.children.length].style.width;
	} else {
		cellStyle.width=Header.rows[0].cells[Row.children.length].style.width;
	}
	*/	
	Row.appendChild(newCell);
	return newCell;
}
function cgeOnMouseDownEnabled() {
	if (event.button==1) {
		activateField(findObjectTagName(event.srcElement,'TD').id.substr(2),gCOLON);
	} else {
		moveFocus(findObjectTagName(event.srcElement,'TD').id,1,1,1);
	}
}
function cgeOnMouseDownDisabled() {
	moveFocus(findObjectTagName(event.srcElement,'TD').id,1,1,1);
}
// ********************** /Row Creation Code ******************************************************
function createInput(pid,pvalue,ptype) {
	var objInput=document.createElement('INPUT');
	objInput.id=pid;
	objInput.value=pvalue;
	objInput.type=ptype;
	gridDIV.appendChild(objInput);
}
function setFocusGrid() {
	var retval=SetFocus('Grid');
	window.event.cancelBubble=true;
	window.event.returnValue=false;
}
function gridAddHeader() {
	var objTable=document.createElement('TABLE');
	objTable.cellSpacing=0;
	objTable.cellPadding=0;
	var objRow=document.createElement('ROW');
	objRow.id="gridKeys";
	objTable.appendChild(objRow);
	gridDIV.appendChild(objTable);
}
function cgeonclick() {
	gridonclick(gridhead,window.event,gridbody,window.event.srcElement);
}
function cgeonmousemove() { // JW SR11734 - added header null check.
	var header = findObjectTagName(window.event.srcElement,'TH');
	if (header != null) {
		gridonmousemove(gridhead,window.event,gridbody,header);
	}
}
function cgeonmousedown() {
	if (event.srcElement.className!='THkey') {
		if (event.srcElement.parentElement.id == 'gridheadRow') { //30-Nov-2005 Steve S: SR13463
		//if (event.srcElement.id.indexOf('FINAPInvCharge2')==-1) {	// Pre-fix for SR13463
			cgeDragColumn();
		}
	}
	gridStartColumnResize();
}
// 9-Mar-2005	JW		SR11848: Added hidden parameter
function cgeHeadFields(objRow,HeadType,Col,innerHTML,fontFamily,fontSize,width,height,backgroundColor,type,hidden,form) {
	var objTH=document.createElement('TH');
	if (Col=='Expand') {
		form='';
	} else {
		form='_'+form+'_';
	}
	if (HeadType=='Key') {
		objTH.className='THkey';
		objTH.id='THkey'+form+Col;		
	} else {
		objTH.className='THfld';
		objTH.id='THfld'+form+Col;
	}
	objTH.innerHTML=innerHTML+' ';
	objTH.unselectable='on';
	objTH.type=type;
	objTH.title=cgeGridDate();
	var objStyle=objTH.style;
	objStyle.fontFamily=fontFamily;
	objStyle.fontSize=fontSize+'pt';
	if (hidden==1) { 
		objStyle.width='0pt';
	} else {
		objStyle.width=width+'pt';
	}
	//objStyle.height='10pt';
	objStyle.backgroundColor=backgroundColor;
	// JW: Might want to change hidden stuff later so that we keep the old name and
	// width (like hideShowCol function)
	objTH.Hidden = hidden==1;
	// shobby
	//objTH.attachEvent('onclick',cgeonclick);
	//if (HeadType!='Key') { // Don't move primary keys
		objTH.attachEvent('onmousedown',cgeonmousedown);  //SR12449
		objTH.attachEvent('onmousemove',cgeonmousemove);
	//}
	objRow.appendChild(objTH);
}
function cgeTest2() {
	var className;
	var obj=findObjectTagName(window.event.srcElement,'TH');
	if (obj!=null) {
		className=obj.className;
		if ((className=='THkey')||(className=='THfld')) {
			cgeonclick();
		}
	}
	window.event.cancelBubble=true;
}
function createDIV(pLeft,pTop) {
	var objDIV=document.createElement("DIV");
	objDIV.id='gridDIV';
	objDIV.className='gDIVsh';
	//objDIV.style.left=pLeft;
	objDIV.style.top=pTop;
	//objDIV.style.height=100;
	//objDIV.style.width=100;
	objDIV.attachEvent('onfocusin',setFocusGrid) ;
	document.getElementById('xxx').appendChild(objDIV);
	//objDIV.style.height=expression("_intMaxHeight_");
	//objDIV.style.width=expression("_intMaxWidth_");
	createInput('activefield','','hidden');
	createInput('nextactivefield','','hidden');
	createInput('nextactivecolor','','hidden');
	createInput('activegrid','','');
	createInput('sharedform',0,'hidden');
	createInput('focusfield','','hidden');
	createInput('test','','hidden');
} 	
	var ShowAllLines=new Array(); //null;
	//var PreviousSelected=null;
// 
// ??				Changed to allow both selected and unselected
//function gridDeleteUnselected(pintCol) {
function gridDeleteSelection(pintCol,areChecked) {
	//var intRows=gridbodyDIV.children[0].children[0].children.length;
	var intRows=TBODY.children.length;
	var i,attr;
	var intRemoved=0;
	var focusField;
	focusField=getFocusField();
	if (focusField!='') {
		var focusRow=getRowNum(focusField);
		var blnShowing=true;
	}
	for (i = intRows; i != 0 ; i--) {
		var row = TBODY.children[i-1];
		var rowNum = getRowNum(row.children[row.children.length-1].id);
		var cell = getCell(rowNum,pintCol);
		if (cell!=null) {
			//attr = cell.checked;
			//if (blnNotCheckBox) {
			//	attr = cell.value;
			//}
			//if (attr == pValue) {
			if (cell.checked==areChecked) {
				if (ShowAllLines[pintCol]==null) {
					row.style.display='none';
					intRemoved++;
					if (rowNum==focusRow) {
						blnShowing=false;
					}
				} else {
					row.style.display='block';
				}
			}
		}
	}
	// If we are on a removed field, we must attempt to find a row above and then below (if we don't find one)
	// to focus on. 
	/*
	if (PreviousSelected!=null) {
		moveFocus(PreviousSelected,1,0,1);
		PreviousSelected=null; 
	} else if */	
	if (intRemoved!=intRows) {
		if (focusField=='') { // go to first cell
			// moveFocus(TBODY.children[0].children[1].id,1,0,1)
			moveFocusTop();
		} else if (!blnShowing) {
			moveFocus(38,0,0,'');
			if (getFocusField()==focusField) {
				moveFocus(40,0,0,'');
			}
		}
	} else if (intRows > 0) {
		//PreviousSelected=focusField;
		moveFocus('',1);
		setFocusField('');
	}
	if (ShowAllLines[pintCol]==null) {
		ShowAllLines[pintCol]=1;
	} else {
		ShowAllLines[pintCol]=null;
	}
}
// JW : 19-Jan-2005 : Get the row number from a cell object id.
function getRowNum(cellObj) {
	return cellObj.split("Y")[1].split("_")[0];
}
function getColNum(cellObj) {
	return cellObj.split("_")[1];
}
// JW : 19-Jan-2005 : Get the cell object from row and column parameters
function getCell(row,col) {
	return document.getElementById('Y'+row+'_'+col)
}
// JW : 1-Feb-2005
function getFocusField() {
	return document.getElementById('focusfield').value;
}
function setFocusField(val) {
	document.getElementById('focusfield').value=val;
}
function getColWidth(intCol,domObj) { // This is necessary since not all cells have a width specified, 1 px dropped so as to be less than col width otherwise wrapping will occur.
   // This is also rather dodgy, subtracting 1 pixel is sometimes enough to prevent wrapping though not always. Don't know if 2 will always prevent wrapping.
   return (parseInt(parseFloat(document.getElementById('THfld'+intCol).style.width)*gridRatio())-2-domObj.children[1].offsetWidth);
}
function getCellWidth(domObj) { // <-- doing this instead of hardcoded as that can be error prone.
	var domParObj=findParentOf(domObj,'td'),
	    width = 0;
	if (domParObj!=null) {
	   if (domParObj.rowIndex==1 || domParObj.id.split('GridRow')[1]==1) {
		   width = domObj.parentNode.offsetWidth;
	   } else {
		   width = domParObj.style.width;
	   }
	}
	return width;
}
function findParentOf(domObj,strType) { // <-- Could extend this to look for odjects with particular ids
   return (domObj.nodeName.toLowerCase()==strType?domObj:typeof(domObj.parentNode)=='object'?findParentOf(domObj.parentNode,strType):null);
}
 	//-->
	//</script>
	

//<script language="javascript">
//<!--
//Globals---------------------------------------------------
var YUSER;
var YUCI;
var YFORM;
var cgeDateFormat;
function InitGlobals(pYUSER,pYUCI,pYFORM,pDateFormat,pYGIF,pYBED) {
	YUSER=pYUSER;
	YUCI=pYUCI;
	YFORM=pYFORM;
	cgeDateFormat=pDateFormat;
	cgeYGIF=pYGIF;
	YBED=pYBED;
}
//Globals---------------------------------------------------
function activateFieldNow(yfield,yhtml,yvalue,yadd) {   //EINF�GEN INPUT FELD IN SOURCE CODE
	if (yadd == 1) {                                      //MEHRFACH-AUFRUF BEI �BERLANGEM CODE (SELECT/MEMO)
		document.getElementById('td'+yfield).innerHTML='';
		ycancel = null;
		for (yline=1 ; yline<=30 ; yline++) {
			windowsetTimeout('loadSelectField(\''+yfield+'\',\''+yline+'\')',1);
			if (ycancel == 1) break;
		}
		windowsetTimeout('showSelectField(\''+yfield+'\',\''+yvalue+'\')',1);
	} else {
		document.getElementById('td'+yfield).innerHTML=unescape(yhtml);
		document.getElementById(yfield).value=unescape(yvalue);
		document.getElementById(yfield).focus();
		/*
		if (document.getElementById(yfield).type=='checkbox') {
			saveData(yfield,!document.getElementById(yfield).checked,'2','mouseclick');
		}
		*/
	}
}
function showSelectField(yfield,yvalue) {               //SPEICHERUNG
	yhtml = document.getElementById('td'+yfield).innerHTML;
	yhtml = yhtml.replace(/_ASCII60_/gi,'<');
	yhtml = yhtml.replace(/_ASCII62_/gi,'>');
	document.getElementById('td'+yfield).innerHTML = yhtml;
	document.getElementById(yfield).value=unescape(yvalue);
	document.getElementById(yfield).focus();
}
function inactivateField(yfield,yhtml,ycolor,yfocus) {   //R�CKHOLEN TEXT FELD UND EINF�GEN IN SOURCE CODE
	// 24-Jan-2004		RobertW		Optimized to one call to the dom to get the oldfield. (SR10061)
	var oldfield='td'+yfield;
	var objField=document.getElementById(oldfield);
	objField.innerHTML=unescape(yhtml);
	objField.style.backgroundColor=ycolor;
	//document.getElementById(oldfield).innerHTML=unescape(yhtml);
	//document.getElementById(oldfield).style.backgroundColor=ycolor;
	document.getElementById('activefield').value='';	  
	//document.getElementById('activefield').style.border=getBorderStyle(document.getElementById('activefield'));  ???
	if (yfocus == 1 ) {
		//document.getElementById('focusfield').value='td'+yfield;
		//document.getElementById('td'+yfield).style.border='2px solid black';
		focusfield = document.getElementById('focusfield').value
		//var Form=document.getElementById(focusfield).parentNode._Form;
		var Form=document.getElementById(oldfield).parentNode._Form;
		var retval = EventValue(YUCI,YUSER,Form,'FIX','GetFontColour^COMGridEdit31R',oldfield,'6','');
		// SR10061 (RPW) Modified to set the background colour as well.
		cgeUpdateStyle(oldfield,retval);
		document.getElementById(focusfield).style.border='2px solid black';
	}
	ysaveevent=null;
	activateNextField();
}
function saveData(yfield,yvalue,ytyp,yevent) {      //FELDVALIDIERUNG UND SPEICHERAUFRUF
  if (yevent=='calendar') ysaveevent=null;
  if (ysaveevent==null) {
    if (yevent != '' && yevent != null) ysaveevent=yevent;
		var Form=document.getElementById('td'+yfield).parentNode._Form
	    retval = EventValue(YUCI,YUSER,Form,'FIXVALID'+ytyp,Form,yvalue,'0',yfield);
 	    windowsetTimeout('saveDataNow("'+yfield+'")',30);
 		//    if (yevent=='calendar') {window.setTimeOut(""document.getElementById('td'+yfield).focus();"",100);}"
 	}
}
function saveDataNow(yfield) {               //SPEICHERUNG
	var Form=document.getElementById('td'+yfield).parentNode._Form
	retval = EventValue(YUCI,YUSER,Form,'FIX','COMGridEdit31S','','6',yfield);
	// SR11573: This call is no longer necessary. ScreenUpdate does it.
	//windowsetTimeout('updateRecord("'+yfield+'")',10);
}
function updateRecord(yline) {          //UPDATE ANDERER FELDER
	var Form=document.getElementById('td'+yline).parentNode._Form
	retval = EventValue(YUCI,YUSER,Form,'FIX','COMGridEdit31S','UPDATE','6',yline);
}
function updateRecordNow(yfield,yhtml,ycolor) {      //UPDATE ANZEIGEN
	document.getElementById('td'+yfield).innerHTML=unescape(yhtml);
	document.getElementById('td'+yfield).style.backgroundColor=ycolor;
}
function activateField(yfield,ycolor) {      //AUFBAU INPUT FELD DURCH HYPEREVENT
	//if (yaddline==null) {
		var objField;
		var ff = document.getElementById('focusfield').value
		if (ff!='') document.getElementById(ff).parentNode.firstChild.style.fontWeight='normal';		//SR11573
		objField=document.getElementById('td'+yfield);
		if (objField!=null) {
			document.getElementById('td'+yfield).parentNode.firstChild.style.fontWeight='bold';
			if (document.getElementById('activefield').value != yfield) {
				document.getElementById('nextactivefield').value=yfield;
				document.getElementById('nextactivecolor').value=ycolor;
			}
			if (document.getElementById('activefield').value == '') {
				activateNextField();
			}
		}
	//}
}
function activateNextField() {   // JW 24-Nov-2004: One click to change focus
	yfield=document.getElementById('nextactivefield').value;
	document.getElementById('nextactivefield').value='';
	ycolor=document.getElementById('nextactivecolor').value;
	if (yfield!='') {
		/* Removed for SR10061 by RobertW
		if (!(document.getElementById('read'+yfield))) {
		*/
		moveFocus('td'+yfield,1,1,1);
		var activeCell = document.getElementById('td'+yfield);
		if (!activeCell.getAttribute("Locked") // enabled
		&& (document.getElementById(yfield)==null)) {  // has no checkbox kid
			document.getElementById('activefield').value=yfield;
			activeCell.style.backgroundColor=ycolor;
			//activeCell.style.border='1px outset';
			var Form=document.getElementById('td'+yfield).parentNode._Form;
			var retval = EventValue(YUCI,YUSER,Form,'FIX','GetFontColour^COMGridEdit31R',focusfield,'6','');
			// SR10061 (RPW) Modified to set the background colour as well.
			cgeUpdateStyle(yfield,retval);
			//cgeUpdateStyle(focusfield,retval);
			yaddline=null;
			var Form=document.getElementById('td'+yfield).parentNode._Form
			retval = EventValue(YUCI,YUSER,Form,'FIX','COMGridEdit31A','','6',yfield);
		}
	}
}
function loadSelectField(yfield,yline) {      //LADEN HTML SELECT CODE
  if (ycancel != 1) {
	var Form=document.getElementById('td'+yfield).parentNode._Form
    retval = EventValue(YUCI,YUSER,Form,'FIX','COMGridEdit31A',yline,'6',yfield);
    if (retval == '') {
	    ycancel=1;
    } else {
	    document.getElementById('td'+yfield).innerHTML+=unescape(retval);
    }
  }
}
function SetLineDefaults(strTextId) {
	// 24-Jan-2005	RPW		Get the language text first for the confirm dialog and then ask the user
	// 						if they wish to set the defaults.
	var retval=EventValue(YUCI,YUSER,YFORM,'FIX','OnGetText^COMGridEdit31Events',strTextId,'6','');
	if (confirm(retval)) {
		retval=EventValue(YUCI,YUSER,YFORM,'FIX','OnSetLineDefaults^COMGridEdit31Events','','6','');
	}
}
function Trim(pstrValue) 
{
	// Not used at the moment, leaving it in as it may be useful one day.
	// Remove leading spaces and carriage returns
	while ((pstrValue.substring(0,1) == ' ') || (pstrValue.substring(0,1) == '\n') || (pstrValue.substring(0,1) == '\r'))
	{
		pstrValue = pstrValue.substring(1,pstrValue.length);
	}
	// Remove trailing spaces and carriage returns
	while ((pstrValue.substring(pstrValue.length-1,pstrValue.length) == ' ') || (pstrValue.substring(pstrValue.length-1,pstrValue.length) == '\n') || (pstrValue.substring(pstrValue.length-1,pstrValue.length) == '\r'))
	{
		pstrValue = pstrValue.substring(0,pstrValue.length-1);
	}
	return pstrValue;
}
function GetToggleField() {
	// 22-Feb-2005		JW		Created - use for FINAPInv AND FINAPVoucher
	var objField = 'YFINAPInvD1';
	if (document.getElementById(objField)==null) {
		objField = 'YFINAPVoucherD15';
	}
	return objField;
}
function ToggleHeader()
{
// This function hides the fieldset above the grid and then moves and resizes the grid.
// 22-Feb-2005		JW		Use for FINAPVoucher as well
// 27-Dec-2004		RPW		Created for 10061
	var lngHeight;
	var objField = GetToggleField();
	//var objFieldSet=findObjectTagName(document.all['YFINAPInvD2'],'FIELDSET');
	var objFieldSet=findObjectTagName(document.all[objField],'FIELDSET');
	if (objFieldSet!=null) {
		if (objFieldSet.style.display!='none') {
			lngHeight=objFieldSet.offsetHeight;
			objFieldSet.style.display='none';
			gridDIV.style.posHeight+=lngHeight;
			EventValue(YUCI,YUSER,YFORM,"ToggleHeader","ToggleHeader^FINAPInv","none","6",gridDIV.style.posHeight);
		} else {
			objFieldSet.style.display='block';
			lngHeight=objFieldSet.offsetHeight;
			gridDIV.style.posHeight-=lngHeight;
			EventValue(YUCI,YUSER,YFORM,"ToggleHeader","ToggleHeader^FINAPInv","block","6",gridDIV.style.posHeight);
		}
	}	
}
function SetGridHeight(pintHeight)
{	
	var objField = GetToggleField();
	var objFieldSet=findObjectTagName(document.all[objField],'FIELDSET');
	if (objFieldSet!='null') {
		objFieldSet.style.display='none';
		gridDIV.style.posHeight=pintHeight
	}
}
function findObjectTagName(objElement,tagName)
{
	var returnValue=null;
	if (objElement!=null) {
		if (objElement.tagName==tagName) {
			returnValue=objElement;
		} else {
			returnValue=findObjectTagName(objElement.parentElement,tagName);
		}
	}
	return returnValue;
}
function gridView() {
	if (gridbody.rows[0].children[2].offsetWidth==0) {
		gridbody.rows[0].children[2].style.width=100;
		gridhead.rows[0].children[2].style.width=100;
	} else {
		gridbody.rows[0].children[2].style.width=0;
		gridhead.rows[0].children[2].style.width=0;
	}
}	
 	//-->
	//</script>
	
