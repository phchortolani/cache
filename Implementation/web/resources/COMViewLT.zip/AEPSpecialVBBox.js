<!--
Function makeMsgBox(tit, mess, icon, buts, defs, mode)
   butVal = icon + buts + defs + mode
   makeMsgBox = MsgBox(mess,butVal,tit)
End Function

Function makeInputBox(title, question, default_answer)
   makeInputBox = InputBox(title,question,default_answer)
End Function
// -->
