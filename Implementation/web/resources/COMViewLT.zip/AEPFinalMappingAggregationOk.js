function AEPFinalMappingAggregationOk() {
	document.WWW.YSORT.value='0'; 
	document.WWW.YOPEN.value=0;
	SAVENOW();
	setTimeout('window.close()',4000);
}