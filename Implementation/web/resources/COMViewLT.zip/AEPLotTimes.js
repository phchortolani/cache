
//alert('before');

function checkTimeValues() {
	//alert('Checking time values.');
	//alert(serverTime);
}

// Adding adittional code to the @net manager pre-defined onBlur.

function d11onblurFunction() {
	//alert('D11 On blur.');
	checkTimeValues();
	d11onblur();
}
var d11onblur = WWW2.YAEPLotD11.onblur;
//WWW2.YAEPLotD11.onblur = d11onblurFunction;

function d12onblurFunction() {
	//alert('D12 On blur.');
	checkTimeValues();
	d12onblur();
}
var d12onblur = WWW2.YAEPLotD12.onblur;
//WWW2.YAEPLotD12.onblur = d12onblurFunction;

function d13onblurFunction() {
	//alert('D13 On blur.');
	checkTimeValues();
	d13onblur();
}
var d13onblur = WWW2.YAEPLotD13.onblur;
//WWW2.YAEPLotD13.onblur = d13onblurFunction;

function d14onblurFunction() {
	//alert('D14 On blur.');
	checkTimeValues();
	d14onblur();
}
var d14onblur = WWW2.YAEPLotD14.onblur;
//WWW2.YAEPLotD14.onblur = d14onblurFunction;

function d1onblurFunction() {
	//alert('D1 On blur.');
	checkTimeValues();
	d1onblur();
}
var d1onblur = WWW2.YAEPLotD1.onblur;
//WWW2.YAEPLotD1.onblur = d1onblurFunction;

function d2onblurFunction() {
	//alert('D2 On blur.');
	checkTimeValues();
	d2onblur();
}
var d2onblur = WWW2.YAEPLotD2.onblur;
//WWW2.YAEPLotD2.onblur = d2onblurFunction;

function d3onblurFunction() {
	//alert('D3 On blur.');
	checkTimeValues();
	d3onblur();
}
var d3onblur = WWW2.YAEPLotD3.onblur;
//WWW2.YAEPLotD3.onblur = d3onblurFunction;

function d4onblurFunction() {
	//alert('D4 On blur.');
	checkTimeValues();
	d4onblur();
}
var d4onblur = WWW2.YAEPLotD4.onblur;
//WWW2.YAEPLotD4.onblur = d4onblurFunction;

function d5onblurFunction() {
	//alert('D5 On blur.');
	checkTimeValues();
	d5onblur();
}
var d5onblur = WWW2.YAEPLotD5.onblur;
//WWW2.YAEPLotD5.onblur = d5onblurFunction;


//alert('after');

