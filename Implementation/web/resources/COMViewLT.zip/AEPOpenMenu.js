/*
 * Opens the menu window
*/

function openMenu(){
	menu = window.open("/csp/aepd/www.cls?EP=WWWMENU&YUSER=6156180&YBED=ANDRE&YUCI=AEPD&YM=0","MENUE","HEIGHT=500,WIDTH=300,SCROLLBARS=YES,RESIZEABLE=YES");
	//alert("ok");
	//alert(windows['MENUE']);
	//document.windows['MENUE'].focus();


}